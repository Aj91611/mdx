#ifndef MEMBER_H
#define MEMBER_H

#include "Person.h"
#include <vector>

class Member : public Person {
private:
    int memberId;
    std::vector<int> booksBorrowed;

public:
    
    Member();
    Member(int memberId, const std::string& name, const std::string& address, const std::string& email);

    
    int getMemberId() const;
    const std::vector<int>& getBooksBorrowed() const;

    
    void setBooksBorrowed(int bookId);

   
};

#endif

