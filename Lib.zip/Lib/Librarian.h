#ifndef LIBRARIAN_H
#define LIBRARIAN_H
#include "Member.h"
#include "Person.h"  

class Librarian : public Person {
private:
    int staffId;
    int salary;
std::vector<Member> members;
public:
    Librarian();
    Librarian(int staffId, const std::string& name, const std::string& address, const std::string& email, int salary);

    int getStaffId() const;
    int getSalary() const;

    void setStaffId(int staffId);
    void setSalary(int salary);

    void addMember();
    void issueBook(int memberId, int bookId);
    void returnBook(int memberId, int bookId);
    void displayBorrowedBooks(int memberId);
    void calcFine(int memberId);
    Member* findMemberById(int memberId);

};

#endif
