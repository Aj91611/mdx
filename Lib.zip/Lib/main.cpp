#include "Librarian.h"
#include <iostream>

int main() {
    Librarian librarian;

    int choice;
    do {
        // Display menu
        std::cout << "\nLibrary Management System Menu:\n"
                  << "1. Add a Member\n"
                  << "2. Issue a Book to a Member\n"
                  << "3. Return a Book\n"
                  << "4. Display All Books Borrowed by Any Individual Member\n"
                  << "5. Calculate a Fine for Overdue Books\n"
                  << "0. Exit\n"
                  << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                librarian.addMember();
                break;
            case 2: {
                int memberId, bookId;
                std::cout << "Enter Member ID: ";
                std::cin >> memberId;
                std::cout << "Enter Book ID: ";
                std::cin >> bookId;
                librarian.issueBook(memberId, bookId);
                break;
            }
            case 3: {
                int memberId, bookId;
                std::cout << "Enter Member ID: ";
                std::cin >> memberId;
                std::cout << "Enter Book ID: ";
                std::cin >> bookId;
                librarian.returnBook(memberId, bookId);
                break;
            }
            case 4: {
                int memberId;
                std::cout << "Enter Member ID: ";
                std::cin >> memberId;
                librarian.displayBorrowedBooks(memberId);
                break;
            }
            case 5: {
                int memberId;
                std::cout << "Enter Member ID: ";
                std::cin >> memberId;
                librarian.calcFine(memberId);
                break;
            }
            case 0:
                std::cout << "Exiting the Library Management System. Goodbye!\n";
                break;
            default:
                std::cout << "Invalid choice. Please enter a valid option.\n";
        }

    } while (choice != 0);

    return 0;
}
