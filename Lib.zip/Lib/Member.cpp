#include "Member.h"


Member::Member() {}

Member::Member(int memberId, const std::string& name, const std::string& address, const std::string& email)
    : Person(name, address, email), memberId(memberId), booksBorrowed() {}


int Member::getMemberId() const {
    return memberId;
}

const std::vector<int>& Member::getBooksBorrowed() const {
    return booksBorrowed;
}


void Member::setBooksBorrowed(int bookId) {
    booksBorrowed.push_back(bookId);
}
