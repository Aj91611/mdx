#include "Book.h"
#include <iostream> 


Book::Book() {}

Book::Book(int bookId, const std::string& bookName, const std::string& authorFirstName, const std::string& authorLastName)
    : bookId(bookId), bookName(bookName), authorFirstName(authorFirstName), authorLastName(authorLastName) {}


int Book::getBookId() const {
    return bookId;
}

std::string Book::getBookName() const {
    return bookName;
}

std::string Book::getAuthorFirstName() const {
    return authorFirstName;
}

std::string Book::getAuthorLastName() const {
    return authorLastName;
}

Date Book::getDueDate() const {
    return dueDate;
}


void Book::setDueDate(const Date& dueDate) {
    this->dueDate = dueDate;
}



void Book::returnBook() {
    if (borrower.getMemberId() != 0) {
         
        borrower.setBooksBorrowed(bookId);
        dueDate = Date(0, 0, 0); 
        borrower = Member(); 
        std::cout << "Book returned successfully!\n";
    } else {
        std::cout << "This book was not borrowed.\n";
    }
}


void Book::borrowBook(Member& borrower, const Date& dueDate) {
    
    this->borrower = borrower;
    this->dueDate = dueDate;

    
    borrower.setBooksBorrowed(bookId);

    std::cout << "Book borrowed successfully!\n";
}
