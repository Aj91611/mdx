#include "Librarian.h"
#include "Book.h"
#include "Member.h"
#include "Date.h"
#include <iostream>

Librarian::Librarian() {}

Librarian::Librarian(int staffId, const std::string& name, const std::string& address, const std::string& email, int salary)
    : Person(name, address, email), staffId(staffId), salary(salary) {}

int Librarian::getStaffId() const {
    return staffId;
}

int Librarian::getSalary() const {
    return salary;
}

void Librarian::setStaffId(int staffId) {
    this->staffId = staffId;
}

void Librarian::setSalary(int salary) {
    this->salary = salary;
}

void Librarian::addMember() {
    std::cout << "Enter member details:\n";
    int memberId;
    std::cout << "Member ID: ";
    std::cin >> memberId;

    std::string name, address, email;

    std::cout << "Name: ";
    std::cin.ignore();  // Ignore the newline character left in the buffer
    std::getline(std::cin, name);

    std::cout << "Address: ";
    std::getline(std::cin, address);

    std::cout << "Email: ";
    std::cin >> email;

    Member newMember(memberId, name, address, email);

    std::cout << "Member added successfully!\n";
    std::cout << "Member Details:\n";
    std::cout << "Member ID: " << newMember.getMemberId() << "\n";
    std::cout << "Name: " << newMember.getName() << "\n";
    std::cout << "Address: " << newMember.getAddress() << "\n";
    std::cout << "Email: " << newMember.getEmail() << "\n";
}

void Librarian::issueBook(int memberId, int bookId) {
    std::cout << "Issuing book " << bookId << " to member " << memberId << "...\n";

    Book book(bookId, "Book Title", "Author First Name", "Author Last Name");
    Member member(memberId, "Member Name", "Member Address", "member@example.com");

    Date dueDate;
    std::cout << "Enter due date:\n";
    int day, month, year;

    std::cout << "Day: ";
    std::cin >> day;
    dueDate.setDay(day);

    std::cout << "Month: ";
    std::cin >> month;
    dueDate.setMonth(month);

    std::cout << "Year: ";
    std::cin >> year;
    dueDate.setYear(year);

    book.borrowBook(member, dueDate);
}

void Librarian::returnBook(int memberId, int bookId) {
    std::cout << "Returning book " << bookId << " from member " << memberId << "...\n";

    Book book(bookId, "Book Title", "Author First Name", "Author Last Name");
    Member member(memberId, "Member Name", "Member Address", "member@example.com");

    book.returnBook();
}
// methods


Member* Librarian::findMemberById(int memberId) {
    for (auto& member : members) {
        if (member.getMemberId() == memberId) {
            return &member;
        }
    }
    return nullptr;
}

void Librarian::displayBorrowedBooks(int memberId) {
    std::cout << "Displaying books borrowed by member " << memberId << "...\n";

    // Retrieve the existing member
    Member* member = findMemberById(memberId);

    if (member) {
        const std::vector<int>& borrowedBooks = member->getBooksBorrowed();
        for (int bookId : borrowedBooks) {
            std::cout << "Book ID: " << bookId << "\n";
        }
    } else {
        std::cout << "Member not found.\n";
    }
}


void Librarian::calcFine(int memberId) {
    std::cout << "Calculating fine for member " << memberId << "...\n";

    Member member(memberId, "Member Name", "Member Address", "member@example.com");

    Date currentDate = Date::getCurrentDate();
    const std::vector<int>& borrowedBooks = member.getBooksBorrowed();

    for (int bookId : borrowedBooks) {
        Book book(bookId, "Book Title", "Author First Name", "Author Last Name");

        if (book.getDueDate() < currentDate) {
            int fine = 10 * currentDate.calculateDifference(book.getDueDate());
            std::cout << "Fine for Book ID " << bookId << ": �" << fine << "\n";
        }
    }
}

