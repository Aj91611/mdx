#include "Date.h"

Date::Date() {}

Date::Date(int day, int month, int year) : day(day), month(month), year(year) {}

int Date::getDay() const {
    return day;
}

int Date::getMonth() const {
    return month;
}

int Date::getYear() const {
    return year;
}

void Date::setDay(int day) {
    this->day = day;
}

void Date::setMonth(int month) {
    this->month = month;
}

void Date::setYear(int year) {
    this->year = year;
}

bool Date::operator<(const Date& other) const {
    if (year != other.year) {
        return year < other.year;
    }
    if (month != other.month) {
        return month < other.month;
    }
    return day < other.day;
}

int Date::calculateDifference(const Date& other) const {
    
    const int daysPerMonth = 30;  
    return (other.year - year) * 365 + (other.month - month) * daysPerMonth + (other.day - day);
}

Date Date::getCurrentDate() {
    auto now = std::chrono::system_clock::now();
    std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
    struct std::tm* timeInfo = std::localtime(&currentTime);
    return Date(timeInfo->tm_mday, timeInfo->tm_mon + 1, timeInfo->tm_year + 1900);
}
